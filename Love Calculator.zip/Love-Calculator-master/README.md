# Love-Calculator
Love Calculator with html css and javascript
